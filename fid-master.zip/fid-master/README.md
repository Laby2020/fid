# fid
This Repository is for the class DIG2500 Fundamentals of Interactive Design
